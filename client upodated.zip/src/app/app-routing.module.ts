import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import {ItemListComponent} from "./components/item-list/item-list.component";
import {CategoryListComponent} from "./components/category-list/category-list.component";
import {RouterModule, Routes} from "@angular/router";


const routes: Routes = [
  { path: 'items', component: ItemListComponent },
  { path: 'categories', component: CategoryListComponent },
];

@NgModule({
  declarations: [],
  imports: [
    CommonModule,
    RouterModule.forRoot(routes)
  ]
})
export class AppRoutingModule { }

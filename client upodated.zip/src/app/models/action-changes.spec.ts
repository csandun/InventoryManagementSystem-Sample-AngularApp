import { ActionChanges } from './action-changes';

describe('ActionChanges', () => {
  it('should create an instance', () => {
    expect(new ActionChanges()).toBeTruthy();
  });
});

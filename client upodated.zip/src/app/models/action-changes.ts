import {FormAction} from "./form-action";
import {Category} from "./category";
import {Item} from "./item";

export class ActionChanges {
  formAction: FormAction;
  changes: Category | Item | undefined;

  constructor(formAction: FormAction, changes: Category | Item) {
    this.formAction = formAction|| FormAction.None;
    this.changes = changes || undefined;
  }
}

import {Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges} from '@angular/core';
import {Form, FormBuilder, FormGroup, Validators} from "@angular/forms";
import {CategoryService} from "../../services/category.service";
import {Category} from "../../models/category";
import {FormAction} from "../../models/form-action";
import {ActionChanges} from "../../models/action-changes";

@Component({
  selector: 'app-category-add',
  templateUrl: './category-add.component.html',
  styleUrls: ['./category-add.component.css']
})
export class CategoryAddComponent implements OnInit, OnChanges {
  @Output() categoryEmitted = new EventEmitter<boolean>();
  @Input() actionChanges: ActionChanges = new ActionChanges(FormAction.None, {} as Category);

  formActions = FormAction;
  currenttFormAction: FormAction = FormAction.None;

  categoryForm: FormGroup = this.fb.group({
    name: ['', Validators.required],
    type: ['', Validators.required]
  })
  isHide: boolean = false;
  submitButton = 'Insert'

  constructor(private fb: FormBuilder, private categoryService: CategoryService) {
  }

  ngOnInit(): void {
  }

  ngOnChanges(changes: SimpleChanges) {
    if (changes['actionChanges']?.currentValue) {
      this.executeAction(changes['actionChanges'].currentValue.formAction);
    }

    if (!(changes['actionChanges']?.currentValue.formAction === FormAction.None || changes['actionChanges']?.currentValue.formAction === FormAction.CREATE)) {
      this.categoryForm.patchValue(changes['actionChanges'].currentValue.changes);
    }
  }

  private executeAction(currentValue: FormAction) {
    this.currenttFormAction = currentValue;
    switch (currentValue) {
      case FormAction.CREATE:
        this.categoryForm.enable();
        this.categoryForm.reset();
        this.submitButton = 'Insert';
        break;
      case FormAction.UPDATE:
        this.categoryForm.enable();
        this.categoryForm.reset();
        this.submitButton = 'Update';
        break;
      case FormAction.DELETE:
        this.categoryForm.disable();
        this.submitButton = 'Delete';
        break;
      case FormAction.VIEW:
        this.categoryForm.disable();
        this.submitButton = 'View';
        break;
    }
  }


  saveCategory() {
    debugger
    switch (this.currenttFormAction) {
      case FormAction.CREATE:
        this.createCategory();
        break;
      case FormAction.UPDATE:
        this.updateCategory();
        break;
      case FormAction.DELETE:
        this.deleteCategory();
        break;
    }

  }

  private createCategory() {
    debugger;
    if (this.categoryForm.invalid) {
      alert('Invalid Form');
      this.categoryEmitted.emit(false);
      return;
    }

    this.categoryService.addCategory(this.categoryForm.value).subscribe(
      (res) => {
        console.log(res);
        alert('Category Added Successfully');
        this.categoryForm.reset()
        this.categoryEmitted.emit(true);

      },
      (err) => {
        console.log(err);
        this.categoryEmitted.emit(false);
      }
    )
  }

  private updateCategory() {
    var cat = {
      id: this.actionChanges.changes?.id,
      name: this.categoryForm.value.name,
      type: this.categoryForm.value.type
    } as Category;
    this.categoryService.updateCategory(cat).subscribe(
      (response) => {
        alert('Category updated successfully');
        this.categoryEmitted.emit(true);
      },
      (error) => {
        console.log(error);
        this.categoryEmitted.emit(false);
      }
    );
  }

  private deleteCategory() {
    this.categoryService.deleteCategory((this.actionChanges.changes as Category).id).subscribe(
      (response) => {
        alert('Category deleted successfully');
        this.categoryEmitted.emit(true);
      },
      (error) => {
        console.log(error);
        this.categoryEmitted.emit(false);
      }
    );
  }
}

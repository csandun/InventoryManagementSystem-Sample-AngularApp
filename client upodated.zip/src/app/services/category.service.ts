import {Injectable} from '@angular/core';
import {Category} from "../models/category";
import {HttpClient} from "@angular/common/http";
import {Observable} from "rxjs";
import {Item} from "../models/item";

@Injectable({
  providedIn: 'root'
})
export class CategoryService {


  categoryUrl = 'https://localhost:44370/api/Categories';

  constructor(private http: HttpClient) { }

  getCategoryIist(): Observable<Category[]> {
    return this.http.get<Category[]>(this.categoryUrl);
  }


  addCategory(category: Category): Observable<any> {
    const headers = { 'content-type': 'application/json'}
    return this.http.post<Category>(this.categoryUrl, category,  {'headers': headers}  );
  }


  deleteCategory(id: number): Observable<Category> {
    return this.http.delete<Category>(this.categoryUrl + '/' + id);
  }


  updateCategory(category: Category): Observable<any> {
    const headers = { 'content-type': 'application/json'}
    return this.http.put<Category>(this.categoryUrl + '/' + category.id, category,{'headers': headers} );
  }


  getCategoryById(id: number): Observable<any> {
    return this.http.get<Category>(this.categoryUrl + '/' + id);
  }
}

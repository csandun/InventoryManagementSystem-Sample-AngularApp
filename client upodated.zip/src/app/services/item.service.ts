import {Injectable} from '@angular/core';
import {Item} from "../models/item";
import {HttpClient} from '@angular/common/http'
import {Observable} from "rxjs";

@Injectable({
  providedIn: 'root'
})
export class ItemService {

  itemUrl = 'http://localhost:44324/items';

  constructor(private http: HttpClient) {
  }

  // get items from the server
  getItemList(): Observable<Item[]> {
    return this.http.get<Item[]>(this.itemUrl);
  }

  // get item by id
  getItemById(id: number): Observable<Item> {
    return this.http.get<Item>(this.itemUrl + '/' + id);
  }

  // add item
  addItem(item: Item): Observable<any> {
    return this.http.post<Item>(this.itemUrl, item);
  }

  // update item
  updateItem(item: Item): Observable<any> {
    return this.http.put<Item>(this.itemUrl + '/' + item.id, item);
  }

  // delete item
  deleteItem(id: number): Observable<any> {
    return this.http.delete<Item>(this.itemUrl + '/' + id);
  }
}
